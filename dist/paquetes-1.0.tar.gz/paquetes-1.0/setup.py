## Configuracion de paquetes distribuidos
## No se ha terminado de configurar debido a que el cmd no reconoce la ruta al disco d

from setuptools import setup

setup(
    name="paquetes",
    version="1.0",
    description="Distribucion de paquetes. Paquetes con calculos generales",
    author="Andres",
    author_email="aavsz0811@gmail.com",
    url="www.dododd.com",
    packages=["paquete", "paquete"]
)