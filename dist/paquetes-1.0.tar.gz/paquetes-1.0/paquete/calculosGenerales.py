def add(num, num2):
    return num + num2

def subs(num, num2):
    return num - num2

